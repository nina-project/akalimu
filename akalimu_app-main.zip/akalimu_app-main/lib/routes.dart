const loginRoute = '/login/';
const registerRoute = '/register/';
const verifyRoute = '/verify/';
const mainUiRoute = '/mainUi/';
const mainPageRoute = '/mainpage/';
const homePageRoute = '/homepage/';
