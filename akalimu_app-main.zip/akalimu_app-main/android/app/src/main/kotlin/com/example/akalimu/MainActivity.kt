package com.example.akalimu

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
