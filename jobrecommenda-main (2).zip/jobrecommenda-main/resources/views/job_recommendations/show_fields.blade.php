<!-- Job Id Field -->
<div class="col-sm-12">
    {!! Form::label('job_id', 'Job Id:') !!}
    <p>{{ $jobRecommendation->job_id }}</p>
</div>

<!-- User Id Field -->
<div class="col-sm-12">
    {!! Form::label('user_id', 'User Id:') !!}
    <p>{{ $jobRecommendation->user_id }}</p>
</div>

